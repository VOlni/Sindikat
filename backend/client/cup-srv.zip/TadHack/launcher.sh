#!/bin/bash

java -jar target/CUP-0.0.jar
