package com.sindikat;
import java.lang.ProcessBuilder;

public class SindikatRestClient implements IRestClient{
    
    public String checkSimSwap() {
        return "sindikat implementation check sim response";
    }
}
