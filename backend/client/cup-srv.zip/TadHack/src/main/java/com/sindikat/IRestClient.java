package com.sindikat;

public interface IRestClient {
    public String checkSimSwap();
}
